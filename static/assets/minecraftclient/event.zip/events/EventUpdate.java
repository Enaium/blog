package me.ihaq.chrome.event.events;

import me.ihaq.chrome.event.Event;

public class EventUpdate extends Event {

    public EventUpdate() {
        super(Type.PRE);
    }

}
