package cn.lightcolour.excel.command.commands;

import cn.lightcolour.excel.Excel;
import cn.lightcolour.excel.command.Command;
import cn.lightcolour.excel.utils.ChatUtils;

public class HelpCommand implements Command {

    @Override
    public boolean run(String[] args) {
        ChatUtils.message("Here are the list of commands:");
        for (Command c : Excel.INSTANCE.commandManager.getCommands().values()) {
            ChatUtils.message(c.usage());
        }
        return true;
    }

    @Override
    public String usage() {
        return "USAGE: -help";
    }

}
