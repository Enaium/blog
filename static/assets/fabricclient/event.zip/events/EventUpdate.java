package cn.lightcolour.excel.event.events;

import cn.lightcolour.excel.event.Event;

public class EventUpdate extends Event {

    public EventUpdate() {
        super(Type.PRE);
    }

}
